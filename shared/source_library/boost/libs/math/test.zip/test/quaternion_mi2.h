// test file for quaternion.hpp

//  (C) Copyright Hubert Holin 2001.
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_QUATERNION_MULTIPLE_INCLUDE_TEST_2
#define BOOST_QUATERNION_MULTIPLE_INCLUDE_TEST_2

void    quaternion_mi2();

#endif /* BOOST_QUATERNION_MULTIPLE_INCLUDE_TEST_2 */
