var apply_8hpp =
[
    [ "apply", "apply_8hpp.html#ga30027c383676084be151ef3c6cf2829f", null ]
];