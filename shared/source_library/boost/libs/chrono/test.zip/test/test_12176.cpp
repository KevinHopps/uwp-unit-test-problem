//  Copyright 2016 Vicente J. Botet Escriba
//  Distributed under the Boost Software License, Version 1.0.
//  See http://www.boost.org/LICENSE_1_0.txt
//  See http://www.boost.org/libs/chrono for documentation.

#include <boost/chrono/chrono.hpp>

int main()
{
    return 0;
}
