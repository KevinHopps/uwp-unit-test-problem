var searchData=
[
  ['net_5fworth',['net_worth',['../struct_d_a_t_a___t_y_p_e.html#a2a7008d5cecd603c1aaf8ff9ed849621',1,'DATA_TYPE']]]
];
