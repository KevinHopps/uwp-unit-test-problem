var searchData=
[
  ['rightshift',['rightshift',['../structrightshift.html',1,'']]]
];
