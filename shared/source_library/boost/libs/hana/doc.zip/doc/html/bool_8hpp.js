var bool_8hpp =
[
    [ "operator\"\"_c", "bool_8hpp.html#a85ac3c47d02722a334181aab540e732c", null ]
];