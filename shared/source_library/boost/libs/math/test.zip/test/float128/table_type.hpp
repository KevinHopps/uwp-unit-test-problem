///////////////////////////////////////////////////////////////
//  Copyright 2012 John Maddock. Distributed under the Boost
//  Software License, Version 1.0. (See accompanying file
//  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_

#ifndef BOOST_MP_TABLE_TYPE

#include <libs/math/test/table_type.hpp>

#define SC_(x) BOOST_FLOATMAX_C(x)

#endif

