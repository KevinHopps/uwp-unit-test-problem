var capture_8hpp =
[
    [ "capture", "capture_8hpp.html#ga41ada6b336e9d5bcb101ff0c737acbd0", null ]
];