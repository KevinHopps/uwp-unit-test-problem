var namespaceboost_1_1locale_1_1gnu__gettext =
[
    [ "messages_info", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info.html", "structboost_1_1locale_1_1gnu__gettext_1_1messages__info" ]
];