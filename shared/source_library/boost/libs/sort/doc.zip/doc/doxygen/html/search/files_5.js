var searchData=
[
  ['generalizedstruct_2ecpp',['generalizedstruct.cpp',['../generalizedstruct_8cpp.html',1,'']]]
];
