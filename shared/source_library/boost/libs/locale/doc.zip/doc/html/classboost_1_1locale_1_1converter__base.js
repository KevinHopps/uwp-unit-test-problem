var classboost_1_1locale_1_1converter__base =
[
    [ "conversion_type", "classboost_1_1locale_1_1converter__base.html#a726bc2bbcbb6f1e550cca14163fb669b", [
      [ "normalization", "classboost_1_1locale_1_1converter__base.html#a726bc2bbcbb6f1e550cca14163fb669bae20bf7eface68062a0b9f2396833354a", null ],
      [ "upper_case", "classboost_1_1locale_1_1converter__base.html#a726bc2bbcbb6f1e550cca14163fb669ba0fee54e09732910ab30856d0e34c8ad2", null ],
      [ "lower_case", "classboost_1_1locale_1_1converter__base.html#a726bc2bbcbb6f1e550cca14163fb669ba2c5c38c6bc6ca01fb9e573c148ba8ebe", null ],
      [ "case_folding", "classboost_1_1locale_1_1converter__base.html#a726bc2bbcbb6f1e550cca14163fb669ba91936aed5b7c3a82b4d2c2354ead03d3", null ],
      [ "title_case", "classboost_1_1locale_1_1converter__base.html#a726bc2bbcbb6f1e550cca14163fb669bac136b257286085de7bd7eb4a7876dfa7", null ]
    ] ]
];