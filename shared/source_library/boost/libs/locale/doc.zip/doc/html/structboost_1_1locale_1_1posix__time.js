var structboost_1_1locale_1_1posix__time =
[
    [ "nanoseconds", "structboost_1_1locale_1_1posix__time.html#aaa1f72a3f4313cd079b08375132c794d", null ],
    [ "seconds", "structboost_1_1locale_1_1posix__time.html#a8209978ee423c6396d8179505ec5fa78", null ]
];