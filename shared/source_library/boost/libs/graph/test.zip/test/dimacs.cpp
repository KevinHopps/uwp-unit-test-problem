// (C) Copyright Andrew Sutton 2009
//
// Use, modification and distribution are subject to the
// Boost Software License, Version 1.0 (See accompanying file
// LICENSE_1_0.txt or http://www.boost.org/LICENSE_1_0.txt)

#include <boost/graph/read_dimacs.hpp>
#include <boost/graph/write_dimacs.hpp>

// This is obviously just a stub test. It's currently only used as a compile
// check to make sure that the includes are appropriate.

int main()
{
    return 0;
}
