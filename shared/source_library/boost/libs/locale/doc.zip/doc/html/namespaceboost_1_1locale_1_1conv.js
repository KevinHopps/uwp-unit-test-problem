var namespaceboost_1_1locale_1_1conv =
[
    [ "conversion_error", "classboost_1_1locale_1_1conv_1_1conversion__error.html", "classboost_1_1locale_1_1conv_1_1conversion__error" ],
    [ "invalid_charset_error", "classboost_1_1locale_1_1conv_1_1invalid__charset__error.html", "classboost_1_1locale_1_1conv_1_1invalid__charset__error" ]
];