Download RapidXml from here
http://rapidxml.sourceforge.net/

and put the contents in the folder rapidxml-1.13 
(adapt version if necessary)
