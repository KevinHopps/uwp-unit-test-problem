var dispatch__if_8hpp =
[
    [ "BOOST_HANA_DISPATCH_IF", "group__group-details.html#ga5de7a0132a80e37c73d544ece1e6dd4e", null ]
];