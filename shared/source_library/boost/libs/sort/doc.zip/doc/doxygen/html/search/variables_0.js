var searchData=
[
  ['a',['a',['../struct_d_a_t_a___t_y_p_e.html#a0f17d79c6492cb604f3da783a5017b54',1,'DATA_TYPE']]]
];
