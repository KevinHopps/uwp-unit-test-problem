var classboost_1_1locale_1_1generic__codecvt__base =
[
    [ "initial_convertion_state", "classboost_1_1locale_1_1generic__codecvt__base.html#af28c4b64af6cbf2eb01c444e2cdf08c3", [
      [ "to_unicode_state", "classboost_1_1locale_1_1generic__codecvt__base.html#af28c4b64af6cbf2eb01c444e2cdf08c3a07029d87e1c62675db6b857d7b6214ec", null ],
      [ "from_unicode_state", "classboost_1_1locale_1_1generic__codecvt__base.html#af28c4b64af6cbf2eb01c444e2cdf08c3a2386c685ac9676370a20d2802184fed1", null ]
    ] ]
];