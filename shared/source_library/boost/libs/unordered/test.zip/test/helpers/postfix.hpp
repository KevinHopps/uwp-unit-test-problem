
// Copyright 2012 Daniel James.
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

// Include this after the boost headers, but before other test headers.

#if defined(__GNUC__)
#pragma GCC diagnostic ignored "-Wfloat-equal"
#endif
